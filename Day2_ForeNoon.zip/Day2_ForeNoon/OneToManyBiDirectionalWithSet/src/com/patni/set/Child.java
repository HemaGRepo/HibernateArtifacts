package com.patni.set;

/**
 * todo: describe Child
 *
 * 
 */
public class Child {
	private String name;
	private Parent parent;

	@Override
	public String toString() {
		return "Child [name=" + name + ", parent=" + parent + "]";
	}

	public Child() {
	}

	public Child(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Parent getParent() {
		return parent;
	}

	public void setParent(Parent parent) {
		this.parent = parent;
	}
}
