package com.patni.set;

import java.util.HashSet;



import org.hibernate.Session;
import org.hibernate.collection.PersistentSet;


import util.HibernateUtil;


/**
 * todo: describe PersistentSetTest
 *
 * @author Steve Ebersole
 */
public class PersistentSetTest {
	public PersistentSetTest() {
	
	}
	public Session openSession()
	{
		return (util.HibernateUtil.getSession());
	}
	
	public void testWriteMethodDirtying() {
		/*Parent parent = new Parent( "gp1" );
		Child child = new Child( "gc1" );
		parent.getChildren().add( child );
		child.setParent( parent );
		
		
		
		
		Child otherChild = new Child( "gc2" );
		parent.getChildren().add(otherChild);
		otherChild.setParent(parent);*/
//Transient
		Session session = openSession();
		session.beginTransaction();
	//session.save( parent );
		//session.save(child);


		
		session.getTransaction().commit();
		Parent p3=(Parent) session.get(Parent.class,"ep1");
		System.out.println(p3.getChildren());
		session.delete(p3);
		
		/*Child c3=(Child) session.get(Child.class,"c1");
		System.out.println(c3.getParent());
		session.delete(c3);*/
		
		session.flush();
		session.close();
		
		
	}
	public static void main(String args[])
	{
		PersistentSetTest t= new  PersistentSetTest();
		t.testWriteMethodDirtying();
	}
}
