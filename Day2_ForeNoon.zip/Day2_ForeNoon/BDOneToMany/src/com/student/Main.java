package com.student;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.util.HibernateUtil;

public class Main {

	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			Address address = new Address("OMR Road", "Chennai", "TN", "600097");
			// By using cascade=all option the address need not be saved
			// explicitly when the student object is persisted the address will
			// be automatically saved.
			// session.save(address);
			Student student1 = new Student("Eswar", address);
			Student student2 = new Student("Joe", address);
			session.save(student1);
			session.save(student2);
			
			
			Address address2 = new Address("Thane", "Mumbai", "MH", "200097");
			// By using cascade=all option the address need not be saved
			// explicitly when the student object is persisted the address will
			// be automatically saved.
			// session.save(address);
			Student student3 = new Student("Kumar", address2);
			Student student4 = new Student("Sam", address2);
			
			Set<Student> s1=new HashSet<Student>();
			s1.add(student3);
			s1.add(student4);
			address2.setPeople(s1);
			
			session.save(student3);
			session.save(student4);
			transaction.commit();
			transaction = session.beginTransaction();
			//Updating the address value
			System.out.println("Updating the address value....");
			address2.setAddressId(50l);
			session.saveOrUpdate(address2);
			
			
			transaction.commit();
			
			System.out.println();
			System.out.println("Retreiving address of student");
			session=HibernateUtil.getSessionFactory().openSession();
			Student temp=new Student();
			session.load(temp,(long)1);
			temp.display();
			
			System.out.println();
			System.out.println("Retreiving students in an address");
			session=HibernateUtil.getSessionFactory().openSession();
			Address a1=new Address();
			session.load(a1,(long)2);
			a1.display();
			
			HibernateUtil.getSessionFactory().close();
		} catch (HibernateException e) {
			//transaction.rollback();
			e.printStackTrace();
		} finally {
			//session.close();
		}

	}

}
