package com.student;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.util.HibernateUtil;

public class Main {

	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			Address address1 = new Address("OMR Road", "Chennai", "TN", "600097");
			Address address2 = new Address("Ring Road", "Banglore", "Karnataka", "560000");
			Address address3 = new Address("Thane", "Mumbai", "MH", "430000");
			Student student1 = new Student("Eswar", address1);
			Student student2 = new Student("Joe", address2);
			Student student3=new Student("Martin",address3);
			//Student student4 = new Student("Ram", address2);
			
			session.save(student1); // Inserts address1 and then stores student1
			session.save(student2);// Inserts address2 and then stores student2
			session.save(student3); // Inserts address3 and then stores student3
			//session.save(student4); 
			
			//session.delete(student2); // It deletes student and address
			//session.delete(address2); 
			transaction.commit();
			session.close();
			Session session2 = HibernateUtil.getSessionFactory().openSession();
			Student s4=(Student) session2.load(Student.class, new Long(1)); 
			// Student has id, name and address
			//Student details is in two tables - address and student table
			//The above method will select only from student table
		System.out.println(s4.getStudentName());
		System.out.println(s4.getStudentAddress().getState());//only now it will go to address table and fetch it
			session2.close();
			
			HibernateUtil.getSessionFactory().close();
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
		//	session2.close();
		}

	}

}
