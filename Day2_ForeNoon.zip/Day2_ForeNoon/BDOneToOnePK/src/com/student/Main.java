package com.student;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.util.HibernateUtil;

public class Main {

	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			Address address = new Address("GD Road", "Trichy", "TN", "600097");
			// By using cascade=all option the address need not be saved
			// explicitly when the student object is persisted the address will
			// be automatically saved.
			
			Student student1 = new Student();
			student1.setStudentName("Anu");
			student1.setStudentAddress(address);
			
			address.setPeople(student1);
		//	session.save(address);
			
			//inserting second student
			
			Address address2 = new Address("Lal Ghat", "PUNE", "MH", "498897");
			// By using cascade=all option the address need not be saved
			// explicitly when the student object is persisted the address will
			// be automatically saved.
			
			Student student2 = new Student();
			student2.setStudentName("Allen");
			student2.setStudentAddress(address2);
			
			address2.setPeople(student2);
		//	session.save(address2);
			
			/*Address address3 = new Address("RK Road", "PUNE", "MH", "45678");
			session.save(address3);*/
			
			/*Student s3=new Student();
			s3.setStudentName("Harsh");
			session.save(s3);*/
			transaction.commit();
			
			System.out.println();
			System.out.println("Retreiving address of student");
			session=HibernateUtil.getSessionFactory().openSession();
			Student temp=new Student();
			session.load(temp,(long)2);
			temp.display();
		//	session.delete(temp);
			session.flush();
			System.out.println();
			System.out.println("Retreiving students in an address");
			session=HibernateUtil.getSessionFactory().openSession();
			Address a1=new Address();
			session.load(a1,(long)1);
			a1.display();
			
			HibernateUtil.getSessionFactory().close();
		} catch (HibernateException e) {
			//transaction.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}

	}

}
