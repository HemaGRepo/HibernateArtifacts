package com.pl;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.igate.Emp_Project;
import com.util.HibernateUtil;

public class Main {
 public static void main(String args[])
 {
	 Session session = HibernateUtil.getSessionFactory().openSession();

		Transaction transaction = session.beginTransaction();
		Emp_Project ep=new Emp_Project();
		ep.setEmpid("3245");
		ep.setPid("P111");
		ep.setEname("Siju");
		ep.setPname("ACS");
		ep.setLoc("Hyd");
      session.save(ep);
    //   System.out.println("Record inserted successfully");
		
		Emp_Project ep2=new Emp_Project();
		ep2.setEmpid("3245");
		ep2.setPid("P112");
		ep2.setEname("Shiv");
		ep2.setPname("CLS");
		ep2.setLoc("Chn");
		session.save(ep2);
		
		transaction.commit();
		
		Emp_Project e3=new Emp_Project();
		e3.setEmpid("3333");
		e3.setPid("P111");
		Emp_Project epnew=(Emp_Project)session.load(Emp_Project.class,e3);
		System.out.println(epnew.getEmpid()+ "  "+epnew.getEname());
		
 }
}
