package com.igate.dao;
import com.igate.entity.*;

import org.hibernate.HibernateException;
import org.hibernate.Transaction;
import org.hibernate.classic.Session;

import com.igate.entity.Student;
import com.igate.util.HibernateUtil;

/*
 * Class Name : StudentDAO
 * 
 * Description : Implements DAO Layer methods to perform various CRUD operations. 
 *             
 *           
 */


public class StudentDAO 
{
	public void insertStudentRecords()
	{
	Session session = null;
	Transaction tx =null;
	
	try { 
		session = HibernateUtil.getSessionFactory().openSession();
		tx = session.beginTransaction();
		
		FulltimeStudent fulltimeStudent = new FulltimeStudent(); 
		fulltimeStudent.setId(3);
		fulltimeStudent.setName("Mangala");
		fulltimeStudent.setYears(4);
		
		session.save(fulltimeStudent);
		
		ParttimeStudent parttimeStudent = new ParttimeStudent(); 
		parttimeStudent.setId(4);
		parttimeStudent.setName("Vinod"); 
		parttimeStudent.setHours(100);
		session.save(parttimeStudent);
				
		Student s1=new Student();
		s1.setId(8);
		s1.setName("Karvy"); 
		session.save(s1);
		
		ParttimeStudent parttimeStudent2 = new ParttimeStudent(); 
		parttimeStudent2.setId(9);
		parttimeStudent2.setName("Oliver"); 
		parttimeStudent2.setHours(34);
		session.save(parttimeStudent2);
		
	//	FulltimeStudent f1=(FulltimeStudent) session.load(FulltimeStudent.class, 1);
	//	System.out.println(f1);
		
		tx.commit();
		System.out.println("Students inserted");
		 
		}
		catch(Exception e)
		{  
			tx.rollback(); 
		}
		finally
		{ 
		session.close();
		} 
	}
	
}
