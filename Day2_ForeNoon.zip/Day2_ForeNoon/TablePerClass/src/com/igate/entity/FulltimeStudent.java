package com.igate.entity;

import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@DiscriminatorValue("FullTime")
public class FulltimeStudent extends Student
{
	
	@Override
	public String toString() {
		return "FulltimeStudent [id=" + getId() + ", name=" + getName() + "years=" + years + "]";
	}
	private int years;
	public int getYears()
	{
		return years;
	}
	public void setYears(int years)
	{
		this.years = years;
	}
} 
