package com.igate.entity;

public class FulltimeStudent extends Student
{
	private int years;
	public int getYears()
	{
		return years;
	}
	public void setYears(int years)
	{
		this.years = years;
	}
} 
