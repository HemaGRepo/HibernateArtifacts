package com.igatepatni;

import java.util.LinkedList;
import java.util.List;

public class Item {
	
public Item()
{
	sizes=new LinkedList<Integer>();
}
long id;
String names;
List<Integer> sizes;

public long getId() {
	return id;
}
public void setId(long id) {
	this.id = id;
}
public String getNames() {
	return names;
}
public void setNames(String names) {
	this.names = names;
}
public List<Integer> getSizes() {
	return sizes;
}
public void setSizes(List<Integer> sizes) {
	this.sizes = sizes;
}

}
