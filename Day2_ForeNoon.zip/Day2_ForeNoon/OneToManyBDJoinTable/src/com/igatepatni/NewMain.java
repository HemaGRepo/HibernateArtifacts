package com.igatepatni;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.util.HibernateUtil;

public class NewMain {
	public static void main(String args[])
	{
	Session session = HibernateUtil.getSessionFactory().openSession();
	Transaction transaction = null;
	try {
		
		transaction = session.beginTransaction();
		Employee e1=new Employee();
		e1.setEname("Artvi");
		Employee e2=new Employee();
		e2.setEname("Aditi");
		Set<Employee> eset=new HashSet<Employee>();
		
		SBU s1=new SBU();
		s1.setSBU_name("L&D");
		e1.setEmpSBU(s1);
		e2.setEmpSBU(s1);
		
		eset.add(e1);
		eset.add(e2);
		s1.setEmp(eset);
		
		
		System.out.println("REached 1");
	   session.save(e1);
		session.save(e2);
		//System.out.println("REached 2");		
	
		//e1.setEmpSBU(s1);
		//e2.setEmpSBU(s1);
		
	//	session.save(s1);
		/*SBU mySBU=(SBU)session.get(SBU.class,17);
		System.out.println(mySBU);
		
		Query q1=session.createQuery("from SBU where SBU_name like 'G%'");
		q1.setMaxResults(1);
		SBU s3=(SBU)q1.uniqueResult();
		Query q2=session.createQuery("from Employee where empSBU=:temp");
		q2.setEntity("temp",s3);
		List emp=q2.list();
		for(Object e3:emp)
			System.out.println(e3);*/
		
		
		
		
		
	transaction.commit();
} catch (HibernateException e)
{
	transaction.rollback();
	e.printStackTrace();
} finally {
	session.close();
}
	}
}
