package com.igatepatni;

import java.util.HashSet;
import java.util.Set;

public class SBU {

	int SBU_Id;
	String SBU_name;
	Set<Employee> emp=new HashSet();
	public int getSBU_Id() {
		return SBU_Id;
	}
	public void setSBU_Id(int sBUId) {
		SBU_Id = sBUId;
	}
	public String getSBU_name() {
		return SBU_name;
	}
	public void setSBU_name(String sBUName) {
		SBU_name = sBUName;
	}
	public Set<Employee> getEmp() {
		return emp;
	}
	public void setEmp(Set<Employee> emp) {
		this.emp = emp;
	}
	public String toString()
	{
		System.out.println("In toString Displaying SBU and EMployees");
		System.out.println(SBU_Id+" "+SBU_name);
		Set<Employee> Emps=emp;
		for(Employee x:Emps)
		{
			System.out.println(x.Empid+" "+x.Ename);
		}
		
		return "true";
	}
	
}
