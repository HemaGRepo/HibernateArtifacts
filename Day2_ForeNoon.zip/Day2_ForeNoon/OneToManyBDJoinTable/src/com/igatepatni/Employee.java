package com.igatepatni;

public class Employee {

	public int getEmpid() {
		return Empid;
	}
	public void setEmpid(int empid) {
		Empid = empid;
	}
	public String getEname() {
		return Ename;
	}
	public void setEname(String ename) {
		Ename = ename;
	}
	public SBU getEmpSBU() {
		return empSBU;
	}
	public void setEmpSBU(SBU empSBU) {
		this.empSBU = empSBU;
	}
	int Empid;
	String Ename;
	SBU empSBU;
	
	public String toString()
	{
		return Empid+" "+Ename+" "+empSBU.SBU_name;
	}
}
