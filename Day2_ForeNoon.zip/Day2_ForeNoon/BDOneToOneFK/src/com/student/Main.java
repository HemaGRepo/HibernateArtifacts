package com.student;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.util.HibernateUtil;

public class Main {

	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			Address address = new Address("OMR Road", "Chennai", "TN", "600097");
			Address address2 = new Address("HDC", "Pune", "MH", "123423");
			// By using cascade=all option the address need not be saved
			// explicitly when the student object is persisted the address will
			// be automatically saved.
			// session.save(address);
		Student student1 = new Student("Eswar", address);
		Student student2 = new Student("Karthik", address2);
			
		//	Student student1=new Student();
		//	student1.setStudentName("Eswar");
			
		//	Student student2=new Student();
		//	student2.setStudentName("Karthik");
		
		
			address.setPeople(student1);
			address2.setPeople(student2);
			
		//	session.save(address);
		//	session.save(address2);
			session.save(student1);
		session.save(student2);
			
			transaction.commit();
			
			/*System.out.println();
			System.out.println("Retreiving address of student");
			session=HibernateUtil.getSessionFactory().openSession();
			Student temp=new Student();
			session.load(temp,(long)1);
			temp.display();
			
			System.out.println();
			System.out.println("Retreiving students in an address");
			session=HibernateUtil.getSessionFactory().openSession();
			Address a1=new Address();
			session.load(a1,(long)4);
			a1.display();*/
			
			HibernateUtil.getSessionFactory().close();
		} catch (HibernateException e) {
			//transaction.rollback();
			e.printStackTrace();
		} finally {
			//session.close();
		}

	}

}
