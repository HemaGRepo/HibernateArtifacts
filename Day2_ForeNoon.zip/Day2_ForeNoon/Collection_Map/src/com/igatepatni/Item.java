package com.igatepatni;

import java.util.List;
import java.util.Map;

public class Item {
	
public Item()
{
	
}
long id;
String names;
Map<String,String> item_properties;

public Map<String, String> getItem_properties() {
	return item_properties;
}
public void setItem_properties(Map<String, String> itemProperties) {
	item_properties = itemProperties;
}
public long getId() {
	return id;
}
public void setId(long id) {
	this.id = id;
}
public String getNames() {
	return names;
}
public void setNames(String names) {
	this.names = names;
}


}
