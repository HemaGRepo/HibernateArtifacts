package com.igatepatni;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import util.HibernateUtil;

public class Main {

	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			
		
			Item i1=new Item();
			i1.setId(45);
			i1.setNames("Mouse");
			
			Map<String, String> prop=new HashMap();
			prop.put("Color","Black");
			prop.put("Description","An optical mouse");
			prop.put("Model","Rwe1234");
			i1.setItem_properties(prop);
			
		   session.save(i1);
		   
		   Item i2=new Item();
		   i2.setId(47);
			i2.setNames("LCD");
			
			Map<String, String> prop2=new HashMap();
			prop2.put("Color","Red");
			prop2.put("Description","A 32inch LCD");
			prop2.put("Model","LC453");
			i2.setItem_properties(prop2);
			
		   session.save(i2);
			
			Item i3=(Item) session.get(Item.class, 47l);
			System.out.println("Item Info");
			System.out.println(" Id : "+i3.getId());
			System.out.println(" Item Name : "+i3.getNames());
			
			System.out.println("Item properties ");
			Map m1=i3.getItem_properties();
			System.out.println(m1);
		   
			transaction.commit();
		} catch (HibernateException e) {
		//	transaction.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}

	}

}
