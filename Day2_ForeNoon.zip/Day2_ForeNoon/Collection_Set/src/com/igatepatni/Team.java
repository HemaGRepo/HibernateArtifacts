package com.igatepatni;

import java.util.Set;

public class Team {
 int id;
 Set names;
 String location;
 public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public Set getNames() {
	return names;
}
public void setNames(Set names) {
	this.names = names;
}
public String getLocation() {
	return location;
}
public void setLocation(String location) {
	this.location = location;
}

 
}
