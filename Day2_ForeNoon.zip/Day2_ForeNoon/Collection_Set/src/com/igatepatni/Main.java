package com.igatepatni;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.util.HibernateUtil;

public class Main {

	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			
		     Set pnames=new HashSet();
		     pnames.add("Tinu");
		     pnames.add("Tinky");
		     pnames.add("Vincy");
		     
		     Team myteam=new Team();
		     myteam.setLocation("Chennai");
		     myteam.setNames(pnames);
		     
		     Set pnames2=new HashSet();
		     pnames2.add("Suresh");
		     pnames2.add("Ramesh");
		     pnames2.add("Ganesh");
		     pnames2.add("Suresh");
		     
		     Team myteam2=new Team();
		     myteam2.setLocation("Pune");
		     myteam2.setNames(pnames2);
		     
		    session.save(myteam2); 
			session.save(myteam);
			transaction.commit();
		} catch (HibernateException e) {
		//	transaction.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}

	}

}
