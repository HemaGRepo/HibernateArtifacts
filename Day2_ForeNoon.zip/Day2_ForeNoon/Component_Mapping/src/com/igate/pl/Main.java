package com.igate.pl;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.igate.entity.*;
import com.igate.util.HibernateUtil;

public class Main {

	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			Address address = new Address("NSB road", "Kolkatta", "WB", "300097");
			Student student = new Student("Jack", address);
		//	session.save(student);
			
			Address address1 = new Address("Hasi Ghat", "Hbd", "TH", "500007");
			Student student1 = new Student("Kiran", address1);
		//	session.save(student1);
			transaction.commit();
			System.out.println(" ========Students inserted========");
			
			Student s1=(Student) session.get(Student.class,1l);
			System.out.println(s1);
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}

	}

}
