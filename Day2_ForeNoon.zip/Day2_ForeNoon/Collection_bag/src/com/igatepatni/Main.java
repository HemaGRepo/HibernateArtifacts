package com.igatepatni;

import java.util.List;
import java.util.LinkedList;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.util.HibernateUtil;

public class Main {

	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			List<Integer> sizes=new LinkedList<Integer>();
			sizes.add(45);
			sizes.add(26);
			sizes.add(18);
			
			Item i1=new Item();
			i1.setNames("Box");
			i1.setSizes(sizes);
		    
		   session.save(i1);
		   
		   List<Integer> sizes2=new LinkedList<Integer>();
			sizes2.add(100);
			sizes2.add(20);
			sizes2.add(37);
			
			Item i2=new Item();
			i2.setNames("TV");
			i2.setSizes(sizes2);
			   session.save(i2);
			
			transaction.commit();
			Item i4=(Item) session.get(Item.class,new Long(1));
			System.out.println(i4.getNames());
			for(Integer temp:i4.getSizes())
			{
				System.out.println(temp);
			}
			
		} catch (HibernateException e) {
		//	transaction.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}

	}

}
