package com.igatepatni.demos;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;


public class CheckInheritance {

	public static void main(String[] args) {
		
		SessionFactory fac=util.HibernateUtil.getSessionFactory();
		Session ses=fac.getCurrentSession();
		Transaction tran=ses.beginTransaction();
		
		
		//For table per concrete class(only Concrete classes would be having corresponding table
		Account a1=new Account();
		a1.setAcc_id(10001);
		ses.save(a1);
		
		SavingsAccount sa=new SavingsAccount();
		sa.setAcc_id(20089);
		sa.setBalance(120000);
		sa.setName("Prem");
		ses.save(sa);
		
		CurrentAccount ca=new CurrentAccount();
		ca.setAcc_id(45555);
	    ca.setName("Viji");
	    ca.setBalance(45000);
	    ca.setOrganisation("Patni");
		ses.save(ca);

	/*	Account a3=new CurrentAccount();
		a3.setAcc_id(13989);
		ses.save(a3);*/
		
		tran.commit();
		System.out.println("Committed");

	}

}
