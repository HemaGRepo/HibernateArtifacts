package com.igatepatni.demos;

public class CurrentAccount extends Account {
 String name;
 String organisation;
 float balance;
 
 public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getOrganisation() {
	return organisation;
}
public void setOrganisation(String organisation) {
	this.organisation = organisation;
}
public float getBalance() {
	return balance;
}
public void setBalance(float balance) {
	this.balance = balance;
}

}
