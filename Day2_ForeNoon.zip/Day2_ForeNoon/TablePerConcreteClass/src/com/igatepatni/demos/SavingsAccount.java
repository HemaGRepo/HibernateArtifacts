package com.igatepatni.demos;

public class SavingsAccount extends Account {
	String name;
	float Balance;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public float getBalance() {
		return Balance;
	}
	public void setBalance(float balance) {
		Balance = balance;
	}


}
