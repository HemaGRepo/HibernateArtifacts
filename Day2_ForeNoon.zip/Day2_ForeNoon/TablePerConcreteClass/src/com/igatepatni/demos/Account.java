package com.igatepatni.demos;

public class Account {
int Acc_id;

public int getAcc_id() {
	return Acc_id;
}

public void setAcc_id(int accId) {
	Acc_id = accId;
}
}
