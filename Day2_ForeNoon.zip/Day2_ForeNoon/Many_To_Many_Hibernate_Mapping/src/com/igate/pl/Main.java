package com.igate.pl;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.igate.entity.*;
import com.igate.util.HibernateUtil;

public class Main {

	public static void main(String[] args) {

		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();

			Course c1=new Course("Computer Science");
			Course c2=new Course("English");
			Course c3=new Course("Maths");
			
			Set<Course> courses = new HashSet<Course>();
			courses.add(c1);
			courses.add(c2);
			
			Set<Course> courses2 = new HashSet<Course>();
			courses2.add(c1);
			courses2.add(c3);

			Student student1 = new Student("Vinod", courses);
			Student student2 = new Student("Pramod", courses2);
			
			session.save(student1);
			session.save(student2);

			transaction.commit();
			System.out.println(" ========Students inserted=========");
			System.out.println("Course doesnt know about student");
			Course c4= (Course) session.get(Course.class,2l);
			System.out.println(c4);
			
			System.out.println("Student knows about courses");
			Student s2=(Student)session.get(Student.class, 4l);
			System.out.println(s2);
			
		} catch (HibernateException e) {
		//	transaction.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}

	}
}
