package com.igatepatni;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.util.HibernateUtil;

public class Main {

	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			
		     String[] pnames={"Tinu","Minu","Linu"};
		    
		     
		     Team myteam=new Team();
		     myteam.setLocation("Chennai");
		     myteam.setNames(pnames);
		     
		    String[] pnames2={"Suresh","Ramesh","Ganesh"};
		   
		     
		     Team myteam2=new Team();
		     myteam2.setLocation("Pune");
		     myteam2.setNames(pnames2);
		     
		    session.save(myteam2); 
			session.save(myteam);
			transaction.commit();
			
			Team teamInfo=(Team) session.get(Team.class,2);
			System.out.println("Team Id : "+teamInfo.getId());
			System.out.println("Team Location : "+teamInfo.getLocation());
			for(String name:teamInfo.getNames())
			System.out.println("Team Members : "+name);
			
		} catch (HibernateException e) {
		//	transaction.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}

	}

}
