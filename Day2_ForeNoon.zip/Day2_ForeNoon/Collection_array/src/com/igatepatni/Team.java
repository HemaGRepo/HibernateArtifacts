package com.igatepatni;

import java.util.Set;

public class Team {
 int id;
 public String[] getNames() {
	return names;
}
public void setNames(String[] names) {
	this.names = names;
}
String[] names;
 String location;
 public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}

public String getLocation() {
	return location;
}
public void setLocation(String location) {
	this.location = location;
}

 
}
