package com.igatepatni;

import java.util.List;
import java.util.LinkedList;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.util.HibernateUtil;

public class Main {

	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = null;
		try {
			transaction = session.beginTransaction();
			List<Integer> sizes=new LinkedList<Integer>();
			sizes.add(45);
			sizes.add(56);
			sizes.add(78);
			
			Item i1=new Item();
			i1.setNames("Box");
			i1.setSizes(sizes);
		    
		   session.save(i1);
		   
		   List<Integer> sizes2=new LinkedList<Integer>();
			sizes2.add(10);
			sizes2.add(20);
			sizes2.add(30);
			
			Item i2=new Item();
			i2.setNames("TV");
			i2.setSizes(sizes2);
			   session.save(i2);
			
			transaction.commit();
		} catch (HibernateException e) {
		//	transaction.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}

	}

}
