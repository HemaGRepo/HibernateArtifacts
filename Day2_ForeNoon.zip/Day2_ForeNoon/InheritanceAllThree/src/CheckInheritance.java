import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;


import com.hibernate.Tb_Corporation;
import com.hibernate.Tb_Individual;
import com.hibernate.Tb_Person;

import com.pay.CashPayment;
import com.pay.CreditPayment;

import com.property.Building;
import com.property.Estate;
import com.property.Land;


public class CheckInheritance {

	public static void main(String[] args) {
		
		SessionFactory fac=util.HibernateUtil.getSessionFactory();
		Session ses=fac.getCurrentSession();
		Transaction tran=ses.beginTransaction();
		
		//For table per subclass (every class would be having individual table)
   	Tb_Individual tb=new Tb_Individual();
		tb.setId(new Integer(84297));
		tb.setCountry("India");
		tb.setFname("Abhinav");
		tb.setLname("Rajhans");
		ses.save(tb);
		
		Tb_Corporation tbb=new Tb_Corporation();
		tbb.setId(new Integer(84331));
		tbb.setCountry("Aus");
		tbb.setName("iGate");
		tbb.setRegistrationno("PKP2521");
		ses.save(tbb);
		
		Tb_Person p1=new Tb_Person();
		p1.setId(56);
		p1.setCountry("US");
		ses.save(p1);
		
		Tb_Individual i2=(Tb_Individual) ses.load(Tb_Individual.class, new Integer(84297));
		System.out.println(i2);
		
		
		/*
		
		//For table per class hierarchy(only one table for whole Hierarchy
	
		CreditPayment p1=new CreditPayment();
		CreditPayment p3=new CreditPayment();
		CashPayment  p2=new CashPayment();
		
		p1.setId(101);
		p1.setMessage("CC Pay");
		p1.setCreditcardtype("HDFC");
		p1.setAmount(5000);
		ses.save(p1);
		
		p3.setId(102);
		p3.setMessage("Pay Bill");
		p3.setCreditcardtype("ICICI");
		p3.setAmount(5000);
		ses.save(p3);
		
		
		p2.setId(103);
		p2.setMessage("Bills");
		p2.setAmount(2000);
		ses.save(p2);
		
		CashPayment  p4=(CashPayment) ses.get(CashPayment.class,103);
		System.out.println("Loaded Cash payment object :"+p4.getAmount());
		
		//For table per concrete class(only Concrete classes would be having corresponding table
		/*
		Land l=new Land();
		Building b=new Building();
		Estate e=new Estate();
		
		
		l.setId(501);
		l.setDescription("It is a Land near Kormongla, Bangalore");
		l.setSqfeet(1000); // Non inherited attribute
		l.setPrice(3000000);
		ses.save(l);
		
		b.setId(502);
		b.setDescription("5 storied Bldg near Kormangla, Bangalore");
		b.setBuldingname("SWAPNER BASA");// Non inherited attribute
		b.setPrice(2500000);
		ses.save(b);
		
		e.setId(567);
		e.setDescription("@ Munnar");
		e.setPrice(45678);
		ses.save(e);
		*/
		tran.commit();

	}

}
