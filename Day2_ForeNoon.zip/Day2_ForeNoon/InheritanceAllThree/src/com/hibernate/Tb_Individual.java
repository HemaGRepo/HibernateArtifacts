package com.hibernate;

public class Tb_Individual extends Tb_Person{
	
	private String fname,lname;



	@Override
	public String toString() {
		return "Tb_Individual [fname=" + fname + ", lname=" + lname
				+ ", getCountry()=" + getCountry() + ", getId()=" + getId()
				+ "]";
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

}
