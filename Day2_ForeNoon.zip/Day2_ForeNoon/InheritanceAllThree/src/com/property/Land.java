package com.property;

public class Land extends Estate{
	
	private double sqfeet;

	public double getSqfeet() {
		return sqfeet;
	}

	public void setSqfeet(double sqfeet) {
		this.sqfeet = sqfeet;
	}

	@Override
	public void setDescription(String description) {
		// TODO Auto-generated method stub
		this.description=description;
	}
	
	

}
