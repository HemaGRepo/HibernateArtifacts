package com.property;

public class Building extends Estate{
	
	private String buldingname;
	
	public String getBuldingname() {
		return buldingname;
	}
	public void setBuldingname(String buldingname) {
		this.buldingname = buldingname;
	}

	@Override
	public void setDescription(String description) {
		// TODO Auto-generated method stub
		this.description=description;
	}

}
