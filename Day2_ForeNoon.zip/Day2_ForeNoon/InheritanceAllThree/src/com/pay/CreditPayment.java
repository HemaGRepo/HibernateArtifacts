package com.pay;

public class CreditPayment extends Payment{
	
	private String creditcardtype;
	private double amount;

	public String getCreditcardtype() {
		return creditcardtype;
	}
	public void setCreditcardtype(String creditcardtype) {
		this.creditcardtype = creditcardtype;
	}
	public double getAmount(){
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount+amount*.01;
	}
}
