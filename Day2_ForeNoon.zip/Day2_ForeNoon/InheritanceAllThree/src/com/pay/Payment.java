package com.pay;

public abstract class Payment {
	
	int id;
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	String message;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public abstract double getAmount() ;
	public abstract void setAmount(double amount); 
}
