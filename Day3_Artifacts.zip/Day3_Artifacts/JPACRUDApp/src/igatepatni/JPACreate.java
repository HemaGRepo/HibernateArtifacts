/**
 * 
 */
package igatepatni;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import igatepatni.Student;

/**
 * @author Administrator
 *
 */
public class JPACreate {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPACRUDApplication");
		EntityManager em = emf.createEntityManager();
		System.out.println("entitymanager created");
		try{
			em.getTransaction().begin();
			Student st = new Student();
			st.setSname("Usha");
			st.setSroll(104);
			st.setScourse("BE");
			em.persist(st);//insert 
			em.getTransaction().commit();
		}
		catch(Exception e){
		e.printStackTrace();
		}
		finally{
			em.close();
		}

	}

}
