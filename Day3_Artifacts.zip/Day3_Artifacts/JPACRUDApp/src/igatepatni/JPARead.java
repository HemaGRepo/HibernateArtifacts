/**
 * 
 */
package igatepatni;

import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

/**
 * @author Administrator
 *
 */
public class JPARead {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPACRUDApplication");
		EntityManager em = emf.createEntityManager();
		try{
			em.getTransaction().begin();
			Query query = em.createQuery("SELECT e.empno,d.dname FROM emp e,dept d where e.deptno=d.deptno");  
			   
			   List results = query.getResultList( ); // Fetches list containing arrays of object  
			   
			   Iterator it = results.iterator( );  
			   
			   while (it.hasNext( )) {  
			   
			     Object[] result = (Object[])it.next(); // Iterating through array object   
			     System.out.println(result[0]);
			     System.out.println(result[1]);
			    
			   
			   }  
			   
			   

			//Select all the record from student table
	       /* Query query = em.createQuery("SELECT count(st) FROM Student st",Student.class);
	        List<Long> result = query.getResultList();
	        System.out.println("Number of Products:"+result.get(0));*/
	    //   System.out.println(query.getSingleResult());
	        /*List<Long> result = query.getResultList();
	      //  System.out.println(result.get(0));
			Iterator<Long> it = result.iterator();
			while (it.hasNext()){
				System.out.println(it.next());
				System.out.print("Id:"+student.getId());
				System.out.print(" Name:"+student.getSname());
				System.out.println(" Course:"+student.getScourse());
			}*/
			em.getTransaction().commit();
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		finally{
			em.close();
		}
	}

}
