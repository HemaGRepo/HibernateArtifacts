package demos;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.Collection;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Main {//
	
//	Please populate certain data in tables before running this Demo
  public static void main(String[] a) throws Exception {
    JPAUtil util = new JPAUtil();

    EntityManagerFactory emf = Persistence.createEntityManagerFactory("ProfessorService");
    EntityManager em = emf.createEntityManager();
    ProfessorService service = new ProfessorService(em);

    em.getTransaction().begin();

   
    long l = service.findSalaryForNameAndDepartment("deptName", "empName");
    
    Professor p1=new Professor();
    Department d1=new Department();
    

    
    //Enter some data in the table before executing..
    util.checkData("select * from Professor");
    util.checkData("select * from Department");

    
    em.getTransaction().commit();
    em.close();
    emf.close();
  }
  
 
  
}