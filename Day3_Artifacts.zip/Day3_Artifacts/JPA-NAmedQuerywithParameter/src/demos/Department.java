package demos;

import java.util.ArrayList;
import java.util.Collection;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Department {
    @Id
    private int id;
    private String name;
    
    public Department(int id, String name, Collection<Professor> employees) {
		super();
		this.id = id;
		this.name = name;
		this.employees = employees;
	}

	@OneToMany(mappedBy="department")
    private Collection<Professor> employees;

    public Department() {
        employees = new ArrayList<Professor>();
    }
    
    public int getId() {
        return id;
    }
    
    public String getName() {
        return name;
    }
    
    public Collection<Professor> getProfessors() {
        return employees;
    }

    public String toString() {
        return "Department no: " + getId() + 
               ", name: " + getName();
    }
}
