package demos;
import javax.persistence.PostPersist;

public class ProfessorDebugListener {
  @PostPersist
  public void auditNewHire(Professor emp) { 
      System.out.println(" called on employee: " + emp.getId());
  }

}
