package cachepack;

import java.sql.Blob;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class AccountPOJO {

	private int accid;

	private int custid;

	private Date createDate;

	private double open_bal;

	private double curr_bal;

	public AccountPOJO() { // if default constructor not given, gives
							// Instantation exception
	}

	
	public int getAccid() {
		return accid;
	}

	public void setAccid(int accid) {
		this.accid = accid;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public double getCurr_bal() {
		return curr_bal;
	}

	public void setCurr_bal(double curr_bal) {
		this.curr_bal = curr_bal;
	}

	public int getCustid() {
		return custid;
	}

	public void setCustid(int custid) {
		this.custid = custid;
	}

	public double getOpen_bal() {
		return open_bal;
	}

	public void setOpen_bal(double open_bal) {
		this.open_bal = open_bal;
	}

}
