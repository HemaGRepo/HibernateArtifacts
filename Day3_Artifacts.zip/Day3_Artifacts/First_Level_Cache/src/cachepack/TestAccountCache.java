package cachepack;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class TestAccountCache {
	public static void main(String[] args) throws Exception {
		AccountPOJO ap = null;
		AccountPOJO ap1 = null;
		SessionFactory sf = new Configuration().configure()
				.buildSessionFactory();
		Session session = sf.openSession();
		org.hibernate.Transaction tran = session.beginTransaction();
		tran.begin();
		
		ap = new AccountPOJO(); 
		 ap.setCustid(101);
		 ap.setOpen_bal(67676.909);
		 ap.setCurr_bal(1234.89);
		 	 
		 ap1=new AccountPOJO(); 
		 ap1.setCustid(102);
		 ap1.setOpen_bal(7777);
		 ap1.setCurr_bal(65);
		 
		 
		 
		//  session.save(ap);
		//  session.save(ap1);
		 session.flush(); 
		  tran.commit();
		  session.close();
		 

		// Testing First level cache when same record is fetched two times
		// within one session
		  /*
		Session session1 = sf.openSession();
		//Hit the DB and u will c d select query  and keep it in cache
		AccountPOJO app = (AccountPOJO) session1.get(AccountPOJO.class, new Integer(1)); 
		System.out.println("first  : "+app.getOpen_bal());
		
		
		//Not Hit the DB but will be got from Cache
		System.out.println("------Fetch the same object again------");
		AccountPOJO app1 = (AccountPOJO) session1.get(AccountPOJO.class, new Integer(1));
		System.out.println("Second  : "+app1.getOpen_bal());					 	      
		
		
		//Hit the DB and u will c d select query  and keep it in cache
		AccountPOJO app2 = (AccountPOJO) session1.get(AccountPOJO.class, new Integer(2)); 
		System.out.println("first - Account 2 : "+app2.getOpen_bal());

		session1.clear();	
		
		System.out.println("------Fetch the same object again - after session clear------");
		AccountPOJO app3 = (AccountPOJO) session1.get(AccountPOJO.class, new Integer(1));
		System.out.println("Second  : "+app3.getOpen_bal());	
		session1.close();
		app3.setOpen_bal(12000); // The value is first searched in Cache and updated and finally updated in DB is updated
		//tran.commit();
		
		
	    for(long i=0;i<=10000000;i++)
		{
			for(long j=0;j<=800;j++);
		}*/
		System.out.println("Testing caching across sessions");
		System.out.println("------Session 2 Starts--------");
		Session session2 = sf.openSession();
		AccountPOJO app2 = (AccountPOJO) session2.get(AccountPOJO.class, new Integer(1));
		System.out.println(app2.getOpen_bal());
		System.out.println("--------Fetching same object again-------");
		AccountPOJO app21 = (AccountPOJO) session2.get(AccountPOJO.class, new Integer(1));
		System.out.println(app21.getOpen_bal());
		session2.evict(app21);
		System.out.println("--------Evict - Fetching same object again -------");
		AccountPOJO app22 = (AccountPOJO) session2.get(AccountPOJO.class, new Integer(1));
		System.out.println(app22.getOpen_bal());

		Session session3 = sf.openSession();
		AccountPOJO app3 = (AccountPOJO) session3.get(AccountPOJO.class, new Integer(1));
		System.out.println(app3.getOpen_bal());
		session2.close();
		session3.close();
/*
		Session session1 = sf.openSession();
		org.hibernate.Transaction tran2 = session.beginTransaction();
		Session session2 = sf.openSession();

		AccountPOJO app = (AccountPOJO) session.get(AccountPOJO.class,
				new Integer(1));
		System.out.println("first" + app.getOpen_bal());
	
		  app.setOpen_bal(12000); session.saveOrUpdate(app); tran.commit();
		 session.evict(app);


		AccountPOJO app1 = (AccountPOJO) session1.get(AccountPOJO.class,
				new Integer(1));
		System.out.println("Second" + app1.getOpen_bal());
		// session1.evict(app1);
	// tran.commit();
		//session.close();
		//session1.close();
*/
	}
}
