package mypack;

import org.hibernate.Session;
import org.hibernate.SessionFactory;



public class ForOurLogic {
	public static void main(String args[])
	{
	//Configuration cfg = new Configuration();
	//cfg.configure("hibernate.cfg.xml");
		SessionFactory factory=HibernateUtil.getSessionFactory();
		Session session = factory.openSession();

	//SessionFactory factory = new Configuration().configure().buildSessionFactory();
	//SessionFactory factory = cfg.buildSessionFactory();
	//Session session = factory.openSession();
org.hibernate.Transaction tran=session.beginTransaction();
	tran.begin();
	Product p=new Product();
	p.setProductId(108);
	p.setProName("Laptop");
	p.setPrice(23299.00);
//	session.save(p);
	
	Product p2=new Product();
	p2.setProductId(590);
	p2.setProName("Hard Disk");
	p2.setPrice(2578.00);
//	session.save(p2);
	tran.commit();
	
	Session session1 = factory.openSession(); //Session level cache(L1) and L2 cache
	Object o=session1.load(Product.class,new Integer(108)); 
	Product s=(Product)o;         
	System.out.println("Loaded object product name is___"+s.getProName());
	System.out.println("Object Loaded successfully.....!!");         
	session1.close();       
	
	System.out.println("------------------------------");         
	System.out.println("Waiting......");          
	try{           Thread.sleep(3000);         }         
	catch (Exception e) {         }                
	System.out.println("7 seconds compelted......!!!!!!!!");  
	System.out.println("------------------------------");     
	
	System.out.println("---- Create a new Session and load the same object ----");
	Session session2 = factory.openSession();         
	Object o2=session2.load(Product.class,new Integer(108));           
	Product s2=(Product)o2;         
	System.out.println("Loaded object product name is___"+s2.getProName());        
	System.out.println("Object loaded from the Database...!!");     
	session2.close();   
	
	
	System.out.println("---- Create a new Session and load the same object ----");
	Session session3 = factory.openSession();         
	Object o3=session3.load(Product.class,new Integer(108));          
	Product s3=(Product)o3;         
	System.out.println("Loaded object product name is___"+s3.getProName());        
	System.out.println("Object loaded from global cache successfully.....!!");        
	session3.close();           
	factory.close(); 
}
}