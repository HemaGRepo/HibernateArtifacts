package example;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


@Entity
@Table(name="student_jpa")

public class Student 
{
	
	@Id
	@GeneratedValue
	private int id;

	public int getId() 
	{
		return id;
	}

	public void setId(int id) 
	{
		this.id = id;
	}
	
	@Column(name="sname", length=10,nullable=false)
	private String sname;

	public String getSname() 
	{
		return sname;
	}

	public void setSname(String sname) 
	{
		this.sname = sname;
	}
	
	@Column(name="s_roll",nullable=false)
	private int sroll;

	public int getSroll() 
	{
		return sroll;
	}

	public void setSroll(int sroll) 
	{
		 this.sroll = sroll;
	}
		
	@Column(name="scourse",length=10,nullable=false)
	private String scourse;

	public String getScourse() 
	{
		return scourse;
	}

	public void setScourse(String scourse) 
	{
		this.scourse = scourse;
	}

}
