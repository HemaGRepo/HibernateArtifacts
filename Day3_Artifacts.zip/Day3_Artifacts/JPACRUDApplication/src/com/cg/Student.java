/**
 * 
 */
package com.cg;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author Administrator
 *
 */
@Entity
@Table(name="student_jpa")
@org.hibernate.annotations.Entity(dynamicUpdate=true)
public class Student {
	
	@Id
	@GeneratedValue
	private int id;

	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	
	@Column(name="sname", length=20,nullable=false)
	private String sname;

	/**
	 * @return the sname
	 */
	public String getSname() {
		return sname;
	}

	/**
	 * @param sname the sname to set
	 */
	public void setSname(String sname) {
		this.sname = sname;
	}
	
	@Column(name="s_roll",length=20,nullable=false)
	private int sroll;

	/**
	 * @return the sroll
	 */
	public int getSroll() {
		return sroll;
	}

	/**
	 * @param sroll the sroll to set
	 */
	public void setSroll(int sroll) {
		this.sroll = sroll;
	}
	
	@Column(name="scourse",length=10,nullable=false)
	private String scourse;

	/**
	 * @return the scourse
	 */
	public String getScourse() {
		return scourse;
	}

	/**
	 * @param scourse the scourse to set
	 */
	public void setScourse(String scourse) {
		this.scourse = scourse;
	}
	
}
