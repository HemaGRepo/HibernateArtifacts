/**
 * 
 */
package com.cg;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.Student;

/**
 * @author Administrator
 *
 */
public class JPACreate {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPACRUDApplication");
		EntityManager em = emf.createEntityManager();
		System.out.println("entitymanager created");
		try{
			em.getTransaction().begin();
			Student st = new Student();
			st.setSname("Veena");
			st.setSroll(22);
			st.setScourse("CSE");
			em.persist(st);//insert , same as Save() in session
			
			Student st2 = new Student();
			st2.setSname("Renu");
			st2.setSroll(33);
			st2.setScourse("IT");
			em.persist(st2);
			
			Student st3 = new Student();
			st3.setSname("Sam");
			st3.setSroll(22);
			st3.setScourse("CSE");
			em.persist(st3);//insert , same as Save() in session
			
			Student st4 = new Student();
			st4.setSname("Vinu");
			st4.setSroll(33);
			st4.setScourse("IT");
			em.persist(st4);
			em.getTransaction().commit();
		}
		catch(Exception e){
		e.printStackTrace();
		}
		finally{
			em.close();
		}

	}

}
