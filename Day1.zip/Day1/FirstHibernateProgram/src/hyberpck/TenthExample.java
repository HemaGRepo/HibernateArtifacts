package hyberpck;

import org.hibernate.LockMode;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class TenthExample {
	public static void main(String[] args) 
	{
		Session session1 = null;
		Session session2 = null;
		Transaction tx = null;

		try 
		{
			// This step will read hibernate.cfg.xml and prepare hibernate for use
			SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
			session1 =sessionFactory.openSession();
						
			Insurance i1=(Insurance) session1.load(Insurance.class, 93L, LockMode.FORCE);
			i1.setInvestedAmount(4500);
			
			
			session2 =sessionFactory.openSession();
			Insurance i2=(Insurance) session2.load(Insurance.class, 93L,LockMode.FORCE);
			i2.setInsuranceName("Lock Demo");
			session2.flush();
			session2.close();
		
			session1.flush(); //commit is called on all objects in the session
			session1.close();
			System.out.println("Done");
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			e.printStackTrace();
	
			{
				System.out.println("Rolling back transaction");
			
			}
		} 
		finally 
		{
			try 
			{
				// Actual contact insertion will happen at this step
				/*session.flush();
				session.close();*/
			} 
			catch (Exception e)
			{
				e.printStackTrace();
			}
		}
	}
}
