package hyberpck;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.Transaction;
/**
* Hibernate example to inset data into Contact table
*/
public class SecondExample
{
	public static void main(String[] args) 
	{
		Session session = null;
		Transaction tx = null;

		try 
		{
			// This step will read hibernate.cfg.xml and prepare hibernate for use
			SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
			session =sessionFactory.openSession();
			tx = session.beginTransaction();
			
			//Create new instance of Insurance and set values in it 
			System.out.println("Inserting Record");
			Insurance ins=new Insurance(); //Transient state - only in Java
			ins.setId(83);
			ins.setInsuranceName("Home Ins");
			ins.setInvestedAmount(12000);
			ins.setInvestmentDate("2017-01-12 12:34:22");
			//Check if Primary key 83 is there -> Yes -> Update
			session.saveOrUpdate(ins);//This will create an INSERT query - Persistent state
			
			System.out.println("Inserting another object...........");
			Insurance ins1=new Insurance(); //Transient state - only in Java
			ins1.setId(93);
			ins1.setInsuranceName("Life cover");
			ins1.setInvestedAmount(14000);
			ins1.setInvestmentDate("2017-01-14 12:34:22");
			//Check if Primary key 93 is there ->No -> Insert
			session.saveOrUpdate(ins1);
			
			//ins and ins1 are in Persistant state
			//Session will update any changes made in the object to the DB
			

		
		session.flush(); //commit is called on all objects in the session

		  tx.commit();
			session.close();
			System.out.println("Done");
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			e.printStackTrace();
		//	if (tx != null) 
			{
				System.out.println("Rolling back transaction");
				//tx.rollback();
			}
		} 
		finally 
		{
			try 
			{
				// Actual contact insertion will happen at this step
				/*session.flush();
				session.close();*/
			} 
			catch (Exception e)
			{
				e.printStackTrace();
			}
		}
	}
}