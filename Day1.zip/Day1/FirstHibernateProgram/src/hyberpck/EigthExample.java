package hyberpck;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
//merge() -Removed
public class EigthExample {
	public static void main(String[] args) 
	{
		Session session1 = null;
		Session session2 = null;
		Transaction tx = null;

		try 
		{
			// This step will read hibernate.cfg.xml and prepare hibernate for use
			SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
			session1 =sessionFactory.openSession();
						
			//Create new instance of Insurance and set values in it 
			System.out.println("Reading Record");
			
			//If id is not there in the table -> get will give you null, load will give an Exception
			Insurance ins1=(Insurance) session1.load(Insurance.class, 93l);		
			System.out.println(ins1);
		
			//Session 1 does not know about Session 2
			System.out.println("-----------Session 2 starts here------------");
			session2 =sessionFactory.openSession();
			Insurance ins2=(Insurance) session2.load(Insurance.class, 93l);		
			System.out.println(ins2);
			ins2.setInvestedAmount(45000);
			
			//U tell session1 that ins2 is the same as ins1 object which is there in session1
			//Make or copy the changes which are made in ins2 by session2
		   session1.merge(ins2);

			
			session1.flush(); //commit is called on all objects in the session
			session1.close();
			System.out.println("Done");
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			e.printStackTrace();
	
			{
				System.out.println("Rolling back transaction");
			
			}
		} 
		finally 
		{
			try 
			{
				// Actual contact insertion will happen at this step
				/*session.flush();
				session.close();*/
			} 
			catch (Exception e)
			{
				e.printStackTrace();
			}
		}
	}
}
