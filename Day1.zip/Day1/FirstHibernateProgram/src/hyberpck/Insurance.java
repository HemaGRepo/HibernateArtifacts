package hyberpck;

public class Insurance {
	  @Override
	public String toString() {
		return "Insurance [insuranceName=" + insuranceName
				+ ", investedAmount=" + investedAmount + ", investmentDate="
				+ investmentDate + ", id=" + id + "]";
	}

	private String insuranceName;
	  private int investedAmount;
	  private String investmentDate;
	  private long id;

	  /**
	   * @return Email
	   */
	  public String getInsuranceName() {
	    return insuranceName;
	  }

	  /**
	   * @return First Name
	   */
	  public int getInvestedAmount() {
	    return investedAmount;
	  }

	  /** 
	   * @return Last name
	   */
	  public String getInvestmentDate() {
	    return investmentDate;
	  }

	  /**
	   * @param string Sets the Email
	   */
	  public void setInsuranceName(String string) {
		  insuranceName = string;
	  }

	  /**
	   * @param string Sets the First Name
	   */
	  public void setInvestedAmount(int string) {
		  investedAmount = string;
	  }

	  /**
	   * @param string sets the Last Name
	   */
	  public void setInvestmentDate(String string) {
		  investmentDate = string;
	  }

	  /**
	   * @return ID Returns ID
	   */
	  public long getId() {
	    return id;
	  }

	  /**
	   * @param l Sets the ID
	   */
	  public void setId(long l) {
	    id = l;
	  }

}
