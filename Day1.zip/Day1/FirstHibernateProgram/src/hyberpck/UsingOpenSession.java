package hyberpck;
import java.io.Serializable;

import org.hibernate.FlushMode;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.Transaction;

public class UsingOpenSession 
{
	public  static void main(String[] args) 
	{
		Session session= null;		
		try 
		{
		// This step will read hibernate.cfg.xml and prepare hibernate for use
			SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
			session =sessionFactory.openSession();
			Transaction tx=session.getTransaction();
			tx.begin();
			Contact contact = new Contact();
			//contact.setId(1); // Primary key has to be unique for every record inserted!
			contact.setFirstName("Steve");
			contact.setLastName("Watson");
			contact.setEmail("w.s@gmail.com"); // Till now contact is not attached to a session - transient 
			
			//Attach it to a session - and call save
			//1st time Contact table is created and contact object is inserted into the table
			System.out.println("primary key="+session.save(contact));
		
			tx.commit();
			
			tx.begin();
			contact.setLastName("Mark");
			tx.commit();
			
			tx.begin();
			Contact contact2 = new Contact();
			//contact.setId(1); // Primary key has to be unique for every record inserted!
			contact2.setFirstName("Venu");
			contact2.setLastName("Srini");
			contact2.setEmail("v.s@gmail.com");
			
		//	session.save(contact2);
			tx.commit();
			
			tx.begin();
		//	session.evict(contact2); //Detached state
		//	contact2.setLastName("Mark");
			
			
		//	Contact c1=(Contact)session.load(Contact.class,24l);
		//	session.delete(c1);
	
			tx.commit();
			
			Contact ct=(Contact)session.get(Contact.class, new Long(19));
			System.out.println(ct);
		//	ct.setFirstName("Anoop");
		//	System.out.println("attached ob  "+ct.getFirstName());
			
			
			System.out.println("Done");
			session.flush();
		//	session.close();
		
		}
		catch(Exception e)
		{
			System.out.println("exp:"+e.getMessage());
			
		} 
		finally 
		{	
				//session.flush();
				//session.close();
			
		}
	}
}