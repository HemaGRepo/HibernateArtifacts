package hyberpck;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
//save() and saveorUpdate() - Persistent
public class ThirdExample {
	public static void main(String[] args) 
	{
		Session session = null;
		Transaction tx = null;

		try 
		{
			// This step will read hibernate.cfg.xml and prepare hibernate for use
			SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
			session =sessionFactory.openSession();
			tx = session.beginTransaction();
			
			//Create new instance of Insurance and set values in it 
			System.out.println("Inserting Record");
			Insurance ins=new Insurance(); //Transient state - only in Java
			ins.setId(50);
			ins.setInsuranceName("GeneralIns");
			ins.setInvestedAmount(5000);
			ins.setInvestmentDate("2016-01-12 12:34:22");
			//Check if Primary key 50 is there -> No -> Insert
			session.saveOrUpdate(ins);//This will create an INSERT query - Persistent state
			
						
			//ins is in Persistant state
			//Session will update any changes made in the object to the DB
			ins.setInvestedAmount(75000);

		
			//session.flush(); //commit is called on all objects in the session

		   tx.commit();
			session.close();
			System.out.println("Done");
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			e.printStackTrace();
		//	if (tx != null) 
			{
				System.out.println("Rolling back transaction");
				//tx.rollback();
			}
		} 
		finally 
		{
			try 
			{
				// Actual contact insertion will happen at this step
				/*session.flush();
				session.close();*/
			} 
			catch (Exception e)
			{
				e.printStackTrace();
			}
		}
	}
}
