package hyberpck;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
//refresh() -Removed
public class NinthExample {
	public static void main(String[] args) 
	{
		Session session1 = null;
		Transaction tx = null;

		try 
		{
			// This step will read hibernate.cfg.xml and prepare hibernate for use
			SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
			session1 =sessionFactory.openSession();
						
			//Create new instance of Insurance and set values in it 
			System.out.println("Reading Record");
			
			//If id is not there in the table -> get will give you null, load will give an Exception
			Insurance ins1=(Insurance) session1.load(Insurance.class, 93l);		
			System.out.println(ins1);
		
			System.out.println(" Going to refresh.....");
		for(int i=0;i<99999;i++)
			{
				for(int j=0;j<99999;j++)
				{
					for(int k=0;k<100000;k++)
					{
						
					}
				}
			}
			
			session1.refresh(ins1); //Reload the object again from the DB
			System.out.println(ins1);
			
		
			session1.flush(); //commit is called on all objects in the session
			session1.close();
			System.out.println("Done");
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			e.printStackTrace();
	
			{
				System.out.println("Rolling back transaction");
			
			}
		} 
		finally 
		{
			try 
			{
				// Actual contact insertion will happen at this step
				/*session.flush();
				session.close();*/
			} 
			catch (Exception e)
			{
				e.printStackTrace();
			}
		}
	}
}
