package hyberpck;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
//update() -Persistent
public class SeventhExample {
	public static void main(String[] args) 
	{
		Session session = null;
		Transaction tx = null;

		try 
		{
			// This step will read hibernate.cfg.xml and prepare hibernate for use
			SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
			session =sessionFactory.openSession();
						
			//Create new instance of Insurance and set values in it 
			System.out.println("Reading Record");
			
			//If id is not there in the table -> get will give you null, load will give an Exception
			//ins is in Persistent state
			Insurance ins=(Insurance) session.load(Insurance.class, 93l);		
			System.out.println(ins);
		
			session.evict(ins); //Detached state -> Remove the object from the session
			
			ins.setInvestedAmount(2000);
			
			session.update(ins); //Persistant state -> Reattach a detached object back to the session 

			
			session.flush(); //commit is called on all objects in the session
			session.close();
			System.out.println("Done");
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			e.printStackTrace();
	
			{
				System.out.println("Rolling back transaction");
			
			}
		} 
		finally 
		{
			try 
			{
				// Actual contact insertion will happen at this step
				/*session.flush();
				session.close();*/
			} 
			catch (Exception e)
			{
				e.printStackTrace();
			}
		}
	}
}
