package com.cg.hibernate.demo;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class CustomerMain {

	public static void main(String[] args) {
		{
		
			// This step will read hibernate.cfg.xml and prepare hibernate for use
				SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
				
				Session session =sessionFactory.openSession();
				//Session s2=sessionFactory.openSession();
				
				Transaction tx=session.getTransaction();
				tx.begin();
				//CRUD - 
				//Save - Create a customer Object
			/*	Customer c1=new Customer(); //Transient state
				c1.setcId(222);
				c1.setcName("Emma");
				c1.setLocation("Chennai");
				c1.setOrderCount(12);
				//Attached to a session and saved in DB
				session.save(c1); //Attach the c1 to session and persist in DB - persistent state
				
				Customer c2=new Customer();
					c2.setcName("Tom");
					c2.setLocation("Delhi");
					c2.setOrderCount(3);
					session.save(c2);*/
				
				//Save
				
				//Load - Create an object in Persistent state
				//Get a customer object whose id is 22 from DB 
				//Load or Get - Read
				Customer temp=(Customer) session.load(Customer.class, 22);
				System.out.println(temp);
				
				//Change in Java object
		    //	temp.setOrderCount(50);
				
		       	session.evict(temp); //temp moves to detached state
		       	session.clear();//Evict all the objects from session
				
				temp.setcName("Arun");
				
				//saveOrUpdate - Update
				session.saveOrUpdate(temp);//Again attach temp to the session 
				
				//delete - delete
				session.delete(temp); //Removed state
				
				tx.commit();
					
				System.out.println("Done");
				session.flush();
				session.close();
				sessionFactory.close();
		}

	}

}
