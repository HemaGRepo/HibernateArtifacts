package com.cg.hibernate.demo;

public class Customer {

@Override
	public String toString() {
		return "Customer [cId=" + cId + ", cName=" + cName + ", location="
				+ location + ", orderCount=" + orderCount + "]";
	}
public int getcId() {
	return cId;
}
public void setcId(int cId) {
	this.cId = cId;
}
public String getcName() {
	return cName;
}
public void setcName(String cName) {
	this.cName = cName;
}
public String getLocation() {
	return location;
}
public void setLocation(String location) {
	this.location = location;
}
public int getOrderCount() {
	return orderCount;
}
public void setOrderCount(int orderCount) {
	this.orderCount = orderCount;
}
int cId;
String cName;
String location;
int orderCount;
}
