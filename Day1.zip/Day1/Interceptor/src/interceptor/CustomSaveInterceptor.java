package interceptor;

import java.io.Serializable;

import org.hibernate.EmptyInterceptor;
import org.hibernate.type.Type;

public class CustomSaveInterceptor extends EmptyInterceptor {
	public boolean onSave(Object entity,
            Serializable id,
            Object[] state,
            String[] propertyNames,
            Type[] types)
	{
	System.out.println("from custom Interceptor;");
	PlayerName playerName=null;
	if (entity instanceof PlayerName){
		
playerName = (PlayerName)entity;
String completeName = playerName.getFirstName() + " " +playerName.getMiddleName()+" "+playerName.getLastName();
		playerName.setCompleteName(completeName);
	}
		return super.onSave(playerName, id, state, propertyNames, types);
	}}
