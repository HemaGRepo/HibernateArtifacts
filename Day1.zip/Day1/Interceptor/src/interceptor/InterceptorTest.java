package interceptor;

import java.util.List;

import org.hibernate.*;
import org.hibernate.cfg.Configuration;
import org.hibernate.classic.Validatable;

public class InterceptorTest {

	public static void main(String[] args) {

		
		Configuration configuration = new Configuration().configure();
		configuration.setInterceptor(new CustomSaveInterceptor());//global
		//The above code sets the CustomSaveInterceptor globally by calling the Configuration.setInterceptor(new CustomSaveInterceptor()). 
		//LoggerInterceptor is configured on the session-basis by calling the
		//SessionFactory.openSession(new LoggerInterceptor()). The createPlayerNames() 
		//method creates some test player objects. 
		//Note that the player object 'same' is created with first-name,
		//middle-name and last-name pointing out to 'Same', which is expected to be captured by the Validator Interceptor. 

	   System.out.println(configuration.getInterceptor());
		SessionFactory sessionFactory = configuration.buildSessionFactory();
   //Session session = sessionFactory.openSession(new LoggerInterceptor());
	Session session = sessionFactory.openSession();
		createPlayerNames(session);
		listPlayerNames(session);
		session.close();
		sessionFactory.close();
	}

	private static void createPlayerNames(Session session){

		PlayerName rahul = createPlayerName("Rahul", "Sharad", "Dravid", "RSD");
		PlayerName dhoni = createPlayerName("Mahendra", "Singh", "Dhoni", "MSD");
		PlayerName karthik = createPlayerName("Krishnakumar", "Dinesh", "Karthik",
							"KDK");
		PlayerName same = createPlayerName("Same1", "Same1", "Same1", "SME");

		Transaction transaction = session.beginTransaction();
		try{
			session.save(rahul);
			session.save(dhoni);
			session.save(karthik);

			Transaction innerTransaction = null;
			try{
				innerTransaction = session.beginTransaction();
				session.save(same);
			}catch(Exception exception){
				System.out.println("\n" + exception.getMessage());
			}finally{
				if (innerTransaction.isActive()){
					innerTransaction.commit();
				}
			}
		}catch(Exception exception){
			System.out.println(exception.getMessage());
			transaction.rollback();
			session.clear();
		}finally{
			if (transaction.isActive()){
				transaction.commit();
			}
		}
		session.flush();
	 
	}

	private static PlayerName createPlayerName(String fName, 
					String mName,String lName, String id){
		PlayerName playerName = new PlayerName();
		playerName.setFirstName(fName);
		playerName.setMiddleName(mName);
		playerName.setLastName(lName);
		playerName.setPrimaryKey(id);
		return playerName;
	}

	private static void listPlayerNames(Session session){
		Query query = session.createQuery("From PlayerName");
		List<PlayerName> allPlayers = query.list();
		System.out.println("\n");
		for(PlayerName player : allPlayers){
			listPlayerName(player);
		} 
	}

	private static void listPlayerName(PlayerName player){
		StringBuilder result = new StringBuilder();
		result.append("First Name = ").append(player.getFirstName())
						.append(" , Middle Name = ")
						.append(player.getMiddleName()).
						append(" , Last Name = ").
						append(player.getLastName()).
		append(" , Full Name = ").append(player.getCompleteName());
		System.out.println(result.toString());
	}

}