package interceptor;

import java.io.Serializable;

import org.hibernate.CallbackException;
import org.hibernate.Session;
import org.hibernate.classic.Lifecycle;
import org.hibernate.classic.Validatable;
import org.hibernate.classic.ValidationFailure;

public class PlayerName implements Validatable, Lifecycle {

	private String firstName;
	private String middleName;
	private String lastName;
	private String completeName;

	private String primaryKey;

	public PlayerName(){

	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getCompleteName() {
		return completeName;
	}

	public void setCompleteName(String completeName) {
		this.completeName = completeName;
	}

	public String getPrimaryKey() {
		return primaryKey;
	}

	public void setPrimaryKey(String primaryKey) {
		this.primaryKey = primaryKey;
	}

	public void validate() throws ValidationFailure {

		if ((firstName.equals(middleName)) && (middleName.equals(lastName))){
	throw new ValidationFailure("First Name, Middle Name and Last Name cannot be the same");
		}

	}

	public boolean onDelete(Session s) throws CallbackException {
		return false;
	}

	public void onLoad(Session s, Serializable id) {
		System.out.println("Loading");
	}								  

	public boolean onSave(Session s) throws CallbackException {
		System.out.println("Saving...");
		return false;
	}

	public boolean onUpdate(Session s) throws CallbackException {
		return false;
	}
}
