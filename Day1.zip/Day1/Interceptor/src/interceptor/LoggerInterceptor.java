package interceptor;

import java.io.Serializable;

import org.hibernate.EmptyInterceptor;
import org.hibernate.type.Type;

public class LoggerInterceptor extends EmptyInterceptor{

	public boolean onSave(Object entity,
            Serializable id,
            Object[] state,
            String[] propertyNames,
            Type[] types)
	{
		System.out.println("from logger Interceptor;");
System.out.println("Saving the persistent Object " +entity.getClass() + " with Id " + id);
     return true;
		//return super.onSave(entity, id, state, propertyNames, types);
	}
}
 

