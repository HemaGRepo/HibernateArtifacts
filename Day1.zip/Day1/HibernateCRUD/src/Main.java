import java.util.List;

import java.util.Iterator;

import org.hibernate.HibernateException;

import org.hibernate.Session;

import org.hibernate.Transaction;

import com.bo.Course;
import com.util.HibernateUtil;

public class Main {

	public static void main(String[] args) {

		Main obj = new Main();

		Long courseId1 = obj.saveCourse("Physics");

		Long courseId2 = obj.saveCourse("Chemistry");

		Long courseId3 = obj.saveCourse("Maths");

		obj.listCourse();

		obj.updateCourse(courseId3, "Mathematics");
		obj.listCourse();

		obj.deleteCourse(courseId2);

		obj.listCourse();
	}

	public Long saveCourse(String courseName)

	{

		Session session = HibernateUtil.getSessionFactory().openSession();

		Transaction transaction = null;

		Long courseId = null;

		try {

			transaction = session.beginTransaction();

			Course course = new Course();

			course.setCourseName(courseName);

			courseId = (Long) session.save(course);
			
			System.out.println("Course inserted with Id : "+courseId);

			transaction.commit();

		} catch (HibernateException e) {

			transaction.rollback();

			e.printStackTrace();

		} finally {

			session.close();

		}

		return courseId;

	}

	public void listCourse()

	{

		Session session = HibernateUtil.getSessionFactory().openSession();

		Transaction transaction = null;

		try {

			transaction = session.beginTransaction();

			List courses = session.createQuery("from Course").list();

			System.out.println("Displaying all courses");
			for (Iterator iterator = courses.iterator(); iterator.hasNext();)

			{

				Course course = (Course) iterator.next();

				System.out.println(course.getCourseId()+"      "+course.getCourseName());

			}

			transaction.commit();
			System.out.println("____________________");
		} catch (HibernateException e) {

			transaction.rollback();

			e.printStackTrace();

		} finally {

			session.close();

		}

	}

	public void updateCourse(Long courseId, String newcourseName)

	{

		Session session = HibernateUtil.getSessionFactory().openSession();

		Transaction transaction = null;

		try {

			transaction = session.beginTransaction();

			Course course = (Course) session.get(Course.class, courseId);//Persistent state
			
			System.out.println("Going to update the course :"+course.getCourseId()+" "+course.getCourseName());
			
			course.setCourseName(newcourseName); //U need not call update

			transaction.commit();

		} catch (HibernateException e) {

			transaction.rollback();

			e.printStackTrace();

		} finally {

			session.close();

		}

	}

	public void deleteCourse(Long courseId)

	{

		Session session = HibernateUtil.getSessionFactory().openSession();

		Transaction transaction = null;

		try {

			transaction = session.beginTransaction();

			Course course = (Course) session.get(Course.class, courseId);//Persistent state

			session.delete(course); //removed state

			transaction.commit();
		} catch (HibernateException e) {

			transaction.rollback();
			e.printStackTrace();

		} finally {

			session.close();

		}
	}

}
