package com.igate;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class ProductMain {
	public static void main(String[] args) {
		Session session = null;
		Transaction tx = null;
		Session session2 = null;
		Transaction tx2 = null;

		try {
			SessionFactory sessionFactory = new Configuration().configure()
					.buildSessionFactory();
			session = sessionFactory.openSession();
			tx = session.beginTransaction();

			
			  product p1=new product(); p1.setPname("LCD"); p1.setQty(18);
			  p1.setPrice(28000f); session.save(p1);
			  
			  product p2=new product(); p2.setPname("iPhone"); p2.setQty(12);
			  p2.setPrice(17000f); session.save(p2);
			 
			 product p3=new product(); p3.setPname("iPad"); p3.setQty(23);
			 p3.setPrice(9000f); session.save(p3);
			
			  product p4=new product(); p4.setPname("Keyb"); p4.setQty(22);
			  p4.setPrice(800f); session.save(p4);
			 
			 product p5=new product(); p5.setPname("SJ7"); p5.setQty(5);
			 p5.setPrice(15000f); session.save(p5);

			
			 Query query3 = session.createQuery("from product s "); 
			 List<product> total3 = query3.list(); 
			 System.out.println("Printing all Products using HQL"); 
			 for (Object temp : total3) 
				 System.out.println(temp);
			 
			 System.out.println("------------------------------------"); 
			 Query query2 = session.createQuery("select sum(s.price) from product s "); 
			 List total2 = query2.list(); 
			 System.out.println("Printing sum using HQL"); 
			 for (Object temp : total2) 
				 System.out.println(temp);
			
     
			Query query = session.createQuery("from product where price>:temp order by price");

			//query.setMaxResults(1);
		//Object total = query.uniqueResult();
			query.setFloat("temp", 10000);
			List total=query.list();
			System.out.println("Printing using HQL");
			for (Object temp : total)
				System.out.println(temp);
			
			//Named Query in HQL
			Query query1 = session.getNamedQuery("HQLpricing");
			query1.setParameter("new_price",22000.00f);
			List results = query1.list();
			System.out.println("Printing using HQLPricing price>22000");
			for (Object temp : results)
				System.out.println(temp);	
			
			tx.commit();
			session.close();

		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
			if (tx != null) {
				System.out.println("Rolling back transaction");
				tx.rollback();
			}
		} finally {
			try {
				// Actual contact insertion will happen at this step
				// session.flush();
				// session.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}
