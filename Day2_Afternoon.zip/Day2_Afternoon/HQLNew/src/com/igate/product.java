package com.igate;

public class product {

	public int productId;
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public int getQty() {
		return qty;
	}
	public void setQty(int qty) {
		this.qty = qty;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public String pname;
	public int qty;
	public float price;
	public product() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public String toString()
	{
		return productId+" "+pname+" "+qty+" "+price;
	}
}
