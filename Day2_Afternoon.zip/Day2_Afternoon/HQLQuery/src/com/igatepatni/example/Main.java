package com.igatepatni.example;
import java.util.List;

import java.util.Iterator;

import org.hibernate.HibernateException;
import org.hibernate.Query;

import org.hibernate.Session;

import org.hibernate.Transaction;
import org.hibernate.SessionFactory;

import org.hibernate.cfg.Configuration;


public class Main {

	public static void main(String[] args) {

		Main obj = new Main();

		obj.listCourse();
	}

	public void listCourse()

	{
		SessionFactory sessionFactory=null;
		Transaction transaction = null;

		try {
		sessionFactory = new Configuration().configure().buildSessionFactory();


		Session session = sessionFactory.openSession();

			transaction = session.beginTransaction();

			//Query qr = session.createQuery("from Course c where c.courseName=:name");
			
			Query query=session.getNamedQuery("HQLName");
			query.setString("name", "Physics");
			List courses=query.list();

			for (Iterator iterator = courses.iterator(); iterator.hasNext();)

			{

				Course course = (Course) iterator.next();
				System.out.println(course.getCourseId());
				System.out.println(course.getCourseName());

			}

			transaction.commit();

		} catch (HibernateException e) {

			transaction.rollback();

			e.printStackTrace();

		} finally {

		//	session.close();

		}

	}

}
