package com.hibernatebook.queries;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Hibernate;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import org.hibernate.criterion.Restrictions;

public class HQLExample {

	public void executeSimpleHQL(Session session) {
		Query query = session.createQuery("from Product");
		List<Product> results = query.list();
		System.out.println("--------All Products--------");
		for(Product temp:results){
			System.out.println(temp);
		}
	//	displayProductsList(results);
	}

	public void executeCommentedHQL(Session session) {
		String hql = "from Supplier";
		Query query = session.createQuery(hql);
		query.setComment("My HQL: " + hql);
		List<Supplier> results = query.list();
		System.out.println("--------All Suppliers--------");
		for(Supplier temp:results){
			System.out.println(temp);
		}
	}

	public void executeFullyQualifiedHQL(Session session) {
		Query query = session
				.createQuery("from com.hibernatebook.queries.Product");
		List<Product> results = query.list();
		System.out.println("--------All Products--------");
		for(Product temp:results){
			System.out.println(temp);
		}
	}

	public void executeProjectionHQL(Session session) {
		System.out.println("...........................................");
		System.out.println("select product.name, product.price");
		Query query = session
				.createQuery("select product.name, product.price from Product product");
		List results = query.list();
		System.out.println("--------All Products, Name and Price--------");
		displayObjectList(results);
	}

	public void executeHQLForRestrictions(Session session) {
		System.out.println("...........................................");
		System.out.println("-----from Product where price > 25.0 and name like '%e%----");
		String hql = "from Product where price > 25.0 and name like '%e%'";
		Query query = session.createQuery(hql);
		List results = query.list();
		displayProductsList(results);
	}

	public void executeNamedParametersHQL(Session session,double ip1) {
		System.out.println("---------Products price>25-----------");
		String hql = "from Product where price > :userIP";
		Query query = session.createQuery(hql);
		query.setDouble("userIP",ip1);
	//	query.setDouble("userIP", 25.0);
		List results = query.list();
		displayProductsList(results);
	}

	public void executeObjectNamedParametersHQL(Session session) {
		System.out.println("---------Products from MegaInc-----------");
		String supplierHQL = "from Supplier where name='MegaInc'"; 
		Query supplierQuery = session.createQuery(supplierHQL);
		Supplier supplier = (Supplier) supplierQuery.list().get(0); //Get the 1st supplier with name MegaInc

		String hql = "from Product as product where product.supplier=:IP";
		Query query = session.createQuery(hql);
		query.setEntity("IP", supplier);
		List results = query.list();
		displayProductsList(results);
	}

	public void executePagingHQL(Session session) {
		Query query = session.createQuery("from Product");
		System.out.println("---Paging start from 2 and disp 3 prod----");
		query.setFirstResult(2);
	    query.setMaxResults(3);
		List results = query.list();
		displayProductsList(results);
	}

	public void executeUniqueResultHQL(Session session) {
		System.out.println("---Unique result---");
		String hql = "from Product where price>25.0";
		Query query = session.createQuery(hql);
		query.setMaxResults(1);
		Product product = (Product) query.uniqueResult();
		// test for null here if needed

		List results = new ArrayList();
		results.add(product);
		displayProductsList(results);
	}

	public void executeOrderHQL(Session session) {
		System.out.println("---Order by price>25---");
		String hql = "from Product p where p.price>25.0 order by p.price desc";
		Query query = session.createQuery(hql);
		List results = query.list();
		displayProductsList(results);
	}

	public void executeOrderTwoPropertiesHQL(Session session) {
		System.out.println("---Order by Supplier n Price---");
		String hql = "from Product p order by p.supplier.name asc, p.price asc";
		Query query = session.createQuery(hql);
		List results = query.list();
		displayProductsList(results);
	}

	public void executeAssociationsHQL(Session session) {
		System.out.println("---Association Join ---");
String hql = "select s.name, p.name, p.price from Product p inner join p.supplier as s";
Query query = session.createQuery(hql);
List results = query.list();
displayObjectsList(results);
	}

	public void executeAssociationObjectsHQL(Session session) {
		System.out.println("---Join and display all columns---");
		String hql = "from Product p inner join p.supplier as s";
		Query query = session.createQuery(hql);
		List results = query.list();
		displayObjectsList(results);
	}

	public void executeFetchAssociationsHQL(Session session) {
		System.out.println("---Fetch Join and display all columns---");
		String hql = "from Supplier s inner join fetch s.products as p";
		Query query = session.createQuery(hql);
		List results = query.list();
		System.out.println(results);
		//displaySupplierList(results);
	}


	public void executeCountHQL(Session session) {
		System.out.println("---Count of Distinct Suppliers---");
		String hql = "select count(distinct product.supplier.name) from Product product";
		Query query = session.createQuery(hql);
		Long result = (Long) query.uniqueResult();
		System.out.println(result);
	}

	public void executeMaxMinHQL(Session session) {
		System.out.println("---max Min of price---");
		String hql = "select min(product.price), max(product.price) from Product product";
		Query query = session.createQuery(hql);
		List results = query.list();
		displayObjectsList(results);
	}

	public void executeNamedQuery(Session session) {

		System.out.println("---Named query---");
		Query query = session
				.getNamedQuery("com.hibernatebook.queries.Product.HQLpricing");
		List results = query.list();
		displayObjectList(results);

	query = session.getNamedQuery("com.hibernatebook.queries.Product.SQLpricing");
		List<Double> result = query.list();
	displayObjectList(result);
	}

	public void executeScalarSQL(Session session) {
		System.out.println("-----Scalar SQL ------");
		String sql = "select avg(product.price) as avgPrice from Product product";

		SQLQuery query = session.createSQLQuery(sql);
		query.addScalar("avgPrice", Hibernate.DOUBLE);
		List results = query.list();
		displayObjectList(results);

	}

	public void executeSelectSQL(Session session) {
		System.out.println("-----Scalar SQL Query------");
		String sql = "select {supplier.*} from Supplier supplier";

		SQLQuery query = session.createSQLQuery(sql);
		query.addEntity("supplier", Supplier.class);
		List results = query.list();
		displaySupplierList(results);

	}

	public void executeUpdateHQL(Session session) {
		String hql = "update Supplier set name = :newName where name = :name";
		Query query = session.createQuery(hql);
		query.setString("newName", "Capgemini");
		query.setString("name", "SuperCorp");
		session.beginTransaction();
		int rowCount = query.executeUpdate();
		System.out.println("Rows affected: " + rowCount);

		session.getTransaction().commit();
		// See the results of the update
		query = session.createQuery("from Supplier");
		List results = query.list();

		//displaySupplierList(results);
	}

	public void executeDeleteHQL(Session session) {
		String hql = "delete from Product where name = :name";
		Query query = session.createQuery(hql);
		query.setString("name", "Mouse");
		int rowCount = query.executeUpdate();
		System.out.println("Rows affected: " + rowCount);

		// See the results of the update
		query = session.createQuery("from Product");
		List results = query.list();

		displayProductsList(results);
	}

	public void populate(Session session) {

		Supplier superCorp = new Supplier();
		superCorp.setName("SuperCorp");
		session.save(superCorp);

		Supplier megaInc = new Supplier();
		megaInc.setName("MegaInc");
		session.save(megaInc);

		Product mouse = new Product("Mouse", "Optical Wheel Mouse", 20.0);
		mouse.setSupplier(superCorp);
		superCorp.getProducts().add(mouse);

		Product mouse2 = new Product("LED", "One Button Mouse", 22.0);
		mouse2.setSupplier(superCorp);
		superCorp.getProducts().add(mouse2);

		Product keyboard = new Product("Keyboard", "101 Keys", 30.0);
		keyboard.setSupplier(megaInc);
		megaInc.getProducts().add(keyboard);

		Software webBrowser = new Software("Web Browser", "Blocks Pop-ups",
				75.0, "2.0");
		webBrowser.setSupplier(superCorp);
		superCorp.getProducts().add(webBrowser);

		Software email = new Software("Email", "Blocks spam", 49.99,
				"4.1 RMX Edition");
		email.setSupplier(megaInc);
		megaInc.getProducts().add(email);
	}

	public void displayObjectList(List list) {
		Iterator iter = list.iterator();
		if (!iter.hasNext()) {
			System.out.println("No objects to display.");
			return;
		}
		while (iter.hasNext()) {
			Object obj = iter.next();
			System.out.println(obj.getClass().getName());
			System.out.println(obj);
		}
	}

	public void displayObjectsList(List list) {
		Iterator iter = list.iterator();
		if (!iter.hasNext()) {
			System.out.println("No objects to display.");
			return;
		}
		while (iter.hasNext()) {
			System.out.println("New object");
			Object[] obj = (Object[]) iter.next();
			for (int i = 0; i < obj.length; i++) {
				System.out.println(obj[i]);
			}

		}
	}

	public void displayProductsList(List list) {

		Iterator iter = list.iterator();
		if (!iter.hasNext()) {
			System.out.println("No products to display.");
			return;
		}
		while (iter.hasNext()) {
			Product product = (Product) iter.next();
			String msg = product.getSupplier().getName() + " \t";
			msg += product.getName() + " \t";
			msg += product.getPrice() + " \t";
			msg += product.getDescription();
			System.out.println(msg);
		}
	}

	public void displaySoftwareList(List list) {
		Iterator iter = list.iterator();
		if (!iter.hasNext()) {
			System.out.println("No software to display.");
			return;
		}
		while (iter.hasNext()) {
			Software software = (Software) iter.next();
			String msg = software.getSupplier().getName() + "\t";
			msg += software.getName() + "\t";
			msg += software.getPrice() + "\t";
			msg += software.getDescription() + "\t";
			msg += software.getVersion();
			System.out.println(msg);
		}
	}

	public void displaySupplierList(List list) {
		Iterator iter = list.iterator();
		if (!iter.hasNext()) {
			System.out.println("No suppliers to display.");
			return;
		}
		while (iter.hasNext()) {
			Supplier supplier = (Supplier) iter.next();
			String msg = supplier.getName();
			System.out.println(msg+supplier.getProducts());
		}
	}

	public static void main(String args[]) throws Exception {
		if (args.length > 1) {
			System.out.println("One parameter expected but " + args.length 	+ " received.");
			return;
		}

		HQLExample example = new HQLExample();

		SessionFactory factory = new AnnotationConfiguration().configure().buildSessionFactory();

		Session session = factory.openSession();
		session.beginTransaction();

		//example.populate(session);
		
	//	example.executeSimpleHQL(session);
	//	example.executeCommentedHQL(session);
	//	example.executeFullyQualifiedHQL(session);
	//	example.executeProjectionHQL(session);
		//example.executeHQLForRestrictions(session);
		//example.executeNamedParametersHQL(session,27.0);
		
		//example.executeObjectNamedParametersHQL(session);
		//example.executePagingHQL(session);
		//example.executeUniqueResultHQL(session);
		
		//example.executeOrderHQL(session);
		//example.executeOrderTwoPropertiesHQL(session);
		
	//	example.executeAssociationsHQL(session);
		//example.executeAssociationObjectsHQL(session);
		
		//example.executeCountHQL(session);
		//example.executeMaxMinHQL(session);
		
		// example.executeScalarSQL(session);
		// example.executeSelectSQL(session);
		// example.executeUpdateHQL(session);
		// example.executeDeleteHQL(session);
		
		example.executeNamedQuery(session);
		/*String action = args[0];
		if (action.equalsIgnoreCase(POPULATE)) {
			System.out.println("pupulatingData");
			example.populate(session);
		} else {
			action = "execute" + action;

			Method method = HQLExample.class.getMethod(action,new Class[] { Session.class });
			method.invoke(example, new Object[] { session });
		}*/
	//	HQLExample hq=new HQLExample();
	//example.populate(session);
	//	System.out.println("-------Products - Update -----------");
	//	hq. executeUpdateHQL( session);
	//	System.out.println("------------------------------");
		
		//hq.executeSelectSQL( session);
	//	System.out.println("------------------------------");
	
	//	Criteria crit = session.createCriteria(Product.class);
		//crit.setFirstResult(2);
		//crit.setMaxResults(2);
	//	crit.add(Restrictions.like("name","Mou%"));
	//	crit.add(Restrictions.gt("price",new Double(20.0)));
	//	List results = crit.list();
	//	hq.displayProductsList(results);

		session.getTransaction().commit();
		session.close();
	}

	private static final String POPULATE = "populate";
}
